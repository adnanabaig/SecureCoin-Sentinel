export default function Head() {
    return (
      <>
        <title>SecureCoin Sentinel</title>
        <meta name="description" content="Detect potential rug pulls in crypto projects." />
      </>
    );
  }
  